Wonderware System Platform 2017 UPDATE 3 SP1 P01 Hot Fix IMS1419756 Installation Instructions
=============================================================================================

Issue
=====
Graphic element reference list incomplete or corrupted. Failed to get embedded symbol at index 1Last known symbol reference = Symbol:xxxx

Software Requirements
=====================
Wonderware System Platform 2017 UPDATE 3 SP1 P01

----------------------------------------------------------------------------------------------------

Contents
========
* Ensure after extracting "HF-IMS1419756.exe" , the following hot fix deliverables are copied to the extracted location

        Default Extracted Location:
        ------------------------------
        Pre Vista OS - [Root Drive]:\Documents and Settings\All Users\Documents\Schneider Electric\HF-IMS1419756
        Vista and later OS - [Root Drive]:\Users\Public\Documents\Schneider Electric\HF-IMS1419756
        or [Root Drive]:\Users\Public\Public Documents\Schneider Electric\HF-IMS1419756


Deliverables                                       File Version
------------                                       -------------
WWCdi.dll                                          5593.474.9382.1
InstallHotfix.exe                                  2018.1025.2854.1

Installation Instructions:
=========================

1. Execute "HF-IMS1419756.exe" to extract Hot Fix deliverables.
   Hot Fix deliverables will be copied to the location: "[Root Drive]:\Users\Public\Documents\Schneider Electric\HF-IMS1419756"

2. Ensure that there are 2 files at the location "[Root Drive]:\Users\Public\Documents\Schneider Electric\HF-IMS1419756"
   a.WWCdi.dll
   b.InstallHotfix.exe

3. Close all ArchestrA IDE and GRAccess Toolkit clients on GR node and remote nodes.

4. From SMC Platform Manager, stop the GR Platform.

5. Stop ArchestA Watchdog service and ArchestrA GalaxyRepository service by executing the following commands from Start->Run 
       Net Stop watchdog_service  
       sc config aaGR start= disabled
       Net Stop aaGR

6. Take a backup of file "WWCdi.dll" located at "[RootDrive]:\Program Files (x86)\Common Files\ArchestrA\Framework\Bin" folder.

7. Replace "WWCdi.dll" file in the location mentioned above with the provided HotFix file.

8. Click on "Yes" button(s) to complete the installation. The Hotfix Manager tool will write the information of the Hot Fix to 
   "<root drive>:\ProgramData\Schneider Electric\Hotfixes\HFDB.xml".

9. Start ArchestrA Watchdog service and ArchestrA GalaxyRepository service by executing the following commands from Start->Run
      sc config aaGR start= auto
      Net Start aaGR
      Net Start watchdog_service

10. From SMC Platform Manager, start GR Platform if not started. Set all the engines running on the GR Platform to ONSCAN.

11. Start ArchestrA IDE and connect to galaxy.

12. The fix needs to be applied to GR Node only.

Other brief details
===================
* On 32-bit OS the Program Files path will be "[RootDrive]:\Program Files\"

* Backup merely involves copying the files to another location. Do not rename the files in the same location.

* Machine does not have to be rebooted.

Copyright notice
================
� 2018 AVEVA Group Plc and its subsidiaries. All rights reserved.
The Schneider Electric industrial software business and AVEVA have merged to trade as AVEVA Group plc, a UK listed company.
The Schneider Electric and Life is On trademarks are owned by Schneider Electric and are being licensed to AVEVA by Schneider Electric.