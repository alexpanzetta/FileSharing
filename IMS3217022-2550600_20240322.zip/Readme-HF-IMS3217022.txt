
ABCIP OIServer HF Installation Instructions
--------------------oOo--------------------

Problem: 
========
A customer encountered communication loss between OI ABCIP and the PLC after executing many windows switches in InTouch.


Solution: 
=========
Changed source code to ensure that CIP connections do not get stuck in BUSY state and messages do not get stuck in PENDING state.


This hotfix also includes: 
==========================
IMS2319939 - ABCIP.exe memory leak
IMS1918050 - Optimise User Defined Data Types-Not reading UDT member


Software Requirements:
======================
Communication Drivers Pack 2020.3 (ABCIP OIServer 8.1)


Note: 
=====
This hotfix contains newer DLLs than the original IMS1918050 hotfix(2022.711.4209.1).
Please go ahead and overwrite with these dlls contained in this hotfix.
IMS1918050 dlls originally had an incorrect file version assigned, which now has been corrected.

Contents
========

Deliverables:          			File Version
-------------          			-------------
ABCIP.dll				2021.1022.4829.1
ABCIPTagParser.dll			2021.1022.4829.1
PredefinedUDT.txt			N/A
Readme-HF-IMS3217022.txt		N/A	
 

Installation Instructions:
==========================

1) Deactivate All instances of ABCIP OIServer from SMC Operations Integration Server Manager.

2) Take a backup of ABCIP.dll located at the location:
	"[root drive]:\Program Files\Wonderware\OI-Server\OI-ABCIP\Bin" for 32-bit machines 
	"[root drive]:\Program Files (x86)\Wonderware\OI-Server\OI-ABCIP\Bin" for 64-bit machines.
   
3) Replace "ABCIP.dll" with the one provided with the HotFix at the location:
	"[root drive]:\Program Files\Wonderware\OI-Server\OI-ABCIP\Bin" for 32-bit machines 
	"[root drive]:\Program Files (x86)\Wonderware\OI-Server\OI-ABCIP\Bin" for 64-bit machines.

4) Take a backup of ABCIPTagParser.dll located at the location:
	"[root drive]:\Program Files\Wonderware\OI-Server\AutoBuild\TagParsers" for 32-bit machines 
	"[root drive]:\Program Files (x86)\Wonderware\OI-Server\AutoBuild\TagParsers" for 64-bit machines.
   
5) Replace "ABCIPTagParser.dll" with the one provided with the HotFix at the location:
	"[root drive]:\Program Files\Wonderware\OI-Server\AutoBuild\TagParsers" for 32-bit machines and 
	"[root drive]:\Program Files (x86)\Wonderware\OI-Server\AutoBuild\TagParsers" for 64-bit machines.

6) Copy PredefinedUDT.txt to the following folder
	"[root drive]:ProgramData\Wonderware\OI-Server\$Operations Integration Supervisory Servers$\OI.ABCIP\OI.ABCIP" 
	
7) Activate all instances of ABCIP OIServer from SMC Operations Integration Server Manager.


Note:  Please ensure step 6 is patched correctly to the apppropriate folder.
--------------------------------------------------

Other Brief Details:
====================
* Backup merely involves copying the files to a safe location.  Do not rename the files in the same location.
* Machine reboot is not required.



Copyright notice
================
� 2024 AVEVA Group Plc. All rights reserved.

